﻿<#
.SYNOPSIS
Downloads Windows Admin Center
.DESCRIPTION
Downloads Windows Admin Center by default from http://aka.ms/WACDownload to %temp%\WAC.msi. You can specify the download URL, the download path and the filename with parameters.
.EXAMPLE
Download-WAC
Downloads Windows Admin Center from http://aka.ms/WACDownload to %temp%\WAC.msi.
.EXAMPLE
Download-WAC -DownloadPath "C:\Temp" -Filename "WindowsAdminCenter.msi"
Downloads Windows Admin Center from http://aka.ms/WACDownload to C:\Temp\WindowsAdminCenter.msi
.PARAMETER DownloadURL
The URL where you want to download Windows Admin Center from.
.PARAMETER DownloadPath
The path where you want to save the download
.PARAMETER Filename
The filename of the downloaded file
#>
[cmdletbinding()]
param (
	[parameter(mandatory = $false, position = 1)]
	[string]$DownloadURL = "http://aka.ms/WACDownload",
	[parameter(mandatory = $false, position = 2)]
	[string]$DownloadPath = "$Env:Temp",
	[parameter(mandatory = $false, position = 3)]
	[string]$Filename = "WAC.msi"
)

Add-Type –AssemblyName System.Windows.Forms

if (Test-Path "$DownloadPath\$Filename")
{
	$MsgBox = [System.Windows.Forms.MessageBox]::Show("File already exists, overwrite?", "Warning", 1)
	if ($MsgBox -eq [System.Windows.Forms.DialogResult]::Cancel)
	{
		return
	}
}

Write-Host "Starting download from $DownloadURL"
Invoke-WebRequest -Uri $DownloadURL -OutFile "$DownloadPath\$Filename"
Write-Host "Downloaded $Filename to $DownloadPath"