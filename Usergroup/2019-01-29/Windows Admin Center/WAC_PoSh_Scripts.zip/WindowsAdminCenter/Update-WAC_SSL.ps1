<#
.SYNOPSIS
Updates SSL certificates for Windows Admin Center
.DESCRIPTION
OpenSSL executable has do be specified to run this script.
Converts pem certificate and private key file (e.g. issued by Let's Encrypt) to pfx certificate, imports it to the certificate store, deletes old certificates (if wanted) and starts a change installation for Windows Admin Center with the new certificate thumbprint.
.EXAMPLE
Update-WAC_SSL -InCertPath "C:\temp\cert.pem" -InKeyPath "C:\Temp\key.pem" -OpenSSLPath "C:\Temp\openssl\openssl.exe"
Updates SSL certificate for Windows Admin Center with pem certificate and private key file from C:\temp using openssl.exe from C:\Temp\openssl\. Deletes pfx file after import, also deletes old certificates from certificate store.
.EXAMPLE
Update-WAC_SSL -InCertPath "C:\temp\cert.pem" -InKeyPath "C:\Temp\key.pem" -OpenSSLPath "C:\Temp\openssl\openssl.exe" -OutPfxPath "C:\temp\cert.pfx" -RemovePfx $false -RemoveOldCerts $false -Port 444
Updates SSL certificate for Windows Admin Center with pem certificate and private key file from C:\temp using openssl.exe from C:\Temp\openssl. Pfx certificate and old certificates aren't deleted. SSL Port is changed to 444.
.PARAMETER InCertPath
Full path to existing pem certificate
.PARAMETER InKeyPath
Full path to existing pem private key file
.PARAMETER OpenSSLPath
Full path to openssl executable
.PARAMETER OutPfxPath
Full output path for pfx certificate
.Parameter RemovePfx
Remove pfx certificate after import
.Parameter RemoveOldCerts
Remove old certificates with the same subject as the new pfx certificate
.Parameter Port
Change SSL Port
#>
[cmdletbinding()]
param (
	[parameter(mandatory = $true, position = 1)]
	[string]$InCertPath,
    [parameter(mandatory = $true, position = 2)]
	[string]$InKeyPath,
    [parameter(mandatory = $true, position = 3)]
	[string]$OpenSSLPath,
    [parameter(mandatory = $false, position = 4)]
	[string]$OutPfxPath = "$Env:Temp\certificate.pfx",
    [parameter(mandatory = $false, position = 5)]
	[boolean]$RemovePfx = $true,
    [parameter(mandatory = $false, position = 6)]
	[boolean]$RemoveOldCerts = $true,
    [parameter(mandatory = $false, position = 7)]
	[int]$Port = 443

)

Add-Type –AssemblyName System.Windows.Forms

Write-Host "Checking supported operating systems"
$OSwmi = Get-WmiObject -class Win32_OperatingSystem
if ($OSwmi.version -like "10.*")
{
	if ($OSwmi.caption -like "*Windows 10*")
	{
		[System.Windows.Forms.MessageBox]::Show("Updating SSL certificate only supported for Windows Server 2016/1709 or newer.", "Error", 0)
	    break
	}
}
else
{
	[System.Windows.Forms.MessageBox]::Show("Operating system not supported! Please use Windows Server 2016/1709 or newer.", "Error", 0)
	break
}

Write-Host "Checking paths"
if (-not (Test-Path "$InCertPath")) {
    [System.Windows.Forms.MessageBox]::Show("Certificate file not found in `"$InCertPath`"", "Error", 0)
    break
}

if (-not (Test-Path "$InKeyPath")) {
    [System.Windows.Forms.MessageBox]::Show("Private key file not found in `"$InKeyPath`"", "Error", 0)
    break
}

if (-not (Test-Path "$OpenSSLPath")) {
    [System.Windows.Forms.MessageBox]::Show("OpenSSL not found in `"$OpenSSLPath`"", "Error", 0)
    break
}

Write-Host "Converting $InCertPath and $InKeyPath to $OutPfxPath"
Start-Process -FilePath "$OpenSSLPath" -ArgumentList "pkcs12 -export -in `"$InCertPath`" -inkey `"$InKeyPath`" -out `"$OutPfxPath`" -passout pass:" -WindowStyle Hidden -Wait

if ($RemoveOldCerts -eq $true) {
    Write-Host "Removing old certificates"
    $CertSubject = Get-PfxCertificate $OutPfxPath | Select-Object -ExpandProperty Subject
    Get-ChildItem -path cert:\LocalMachine\My | Where-Object {$_.Subject -like "$CertSubject"} | Remove-Item
}

Write-Host "Importing $OutPfxPath to personal certificate store"
$CertThumbprint = Import-PfxCertificate -FilePath "$OutPfxPath" -CertStoreLocation Cert:\LocalMachine\My | Select-Object -ExpandProperty Thumbprint

if ($RemovePfx -eq $true) {
    Write-Host "Removing $OutPfxPath"
    Remove-Item -Path "$OutPfxPath" -Force
}

Write-Host "Changing SSL certificate for Windows Admin Center"
$WACGUID = get-wmiobject Win32_Product | Where-Object {$_.Name -eq "Windows Admin Center"} | Select-Object -ExpandProperty IdentifyingNumber
$Installation = Start-Process -FilePath "MsiExec.exe" -ArgumentList "/I$WACGUID REGISTRY_REDIRECT_PORT_80=1 SME_PORT=$Port SME_THUMBPRINT=$CertThumbprint SSL_CERTIFICATE_OPTION=installed" -PassThru

Write-Verbose "Sleep 10 seconds"
Start-Sleep -Seconds 10
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
Write-Verbose "Send key alt+n"
[System.Windows.Forms.SendKeys]::SendWait("%{n}")
Write-Verbose "Sleep 2 seconds"
Start-Sleep -Seconds 2
Write-Verbose "Send key alt+c"
[System.Windows.Forms.SendKeys]::SendWait("%{c}")
Write-Verbose "Sleep 2 seconds"
Start-Sleep -Seconds 2
Write-Verbose "Copy $Port to clipboard"
Set-Clipboard -Value $Port
Write-Verbose "Send key ctrl+v"
[System.Windows.Forms.SendKeys]::SendWait("^{v}")
Write-Verbose "Send key tab"
[System.Windows.Forms.SendKeys]::SendWait("{TAB}")
Write-Verbose "Send key tab"
[System.Windows.Forms.SendKeys]::SendWait("{TAB}")
Write-Verbose "Copy $CertThumbprint to clipboard"
Set-Clipboard -Value $CertThumbprint
Write-Verbose "Send key ctrl+v"
[System.Windows.Forms.SendKeys]::SendWait("^{v}")
Write-Verbose "Send key alt+c"
[System.Windows.Forms.SendKeys]::SendWait("%{c}")
Write-Verbose "Sleep 45 seconds"
Start-Sleep -Seconds 45
Write-Verbose "Send key alt+f"
[System.Windows.Forms.SendKeys]::SendWait("%{f}")

Wait-Process -InputObject $Installation -ErrorAction SilentlyContinue
if ($Installation.ExitCode -eq 0 -or $Installation.ExitCode -eq 3010)
{
	Write-Host "Installation successful: Exitcode "$Installation.ExitCode
	break
}
else
{
	[System.Windows.Forms.MessageBox]::Show("Installation failed: Exitcode " + $Installation.ExitCode, "Error", 0)
	break
}