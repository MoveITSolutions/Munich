﻿<#
.SYNOPSIS
Installs Windows Admin Center
.DESCRIPTION
Installs Windows Admin Center in desktop mode on Windows 10 clients or in gateway mode on Windows Server 2016/1709 or newer. If no parameter is given, the setup will start from %temp%\WAC.msi, port 443 will be used and a self signed certificate will be generated.
For desktop mode a port higher than 1023 has to be specified with the "-Port" Parameter.
If you want to use your own SSL certificate you have to use either "-UseCertificate Request" (to let the script request a web server certificate from your ca) or "-UseCertificate Existing". With this option you can specify an already imported certificate by either using the certificate picker GUI during the script runtime or by using "-Thumbprint <thumbprint>".
.EXAMPLE
Install-WAC
Installs Windows Admin Center from $temp\WAC.msi with port 443 and generates a self signed certificate. This will not work for an installation on Windows 10 because a Port higher than 1023 has to be used in desktop mode.
.EXAMPLE
Install-WAC -Port 6515
Installs Windows Admin Center from $temp\WAC.msi with port 6515 and generates a self signed certificate. This will work for an installation on Windows 10.
.EXAMPLE
Install-WAC -SetupPath "C:\Temp\WindowsAdminCenter.msi" -Port 6515
Installs Windows Admin Center from C:\Temp\WindowsAdminCenter.msi with port 6515 and generates a self signed certificate. This will work for an installation on Windows 10.
.EXAMPLE
Install-WAC -UseCertificate Request
Installs Windows Admin Center from $temp\WAC.msi with port 443 and requests a web server certificate from your ca.
.EXAMPLE
Install-WAC -UseCertificate Existing
Installs Windows Admin Center from $temp\WAC.msi with port 443 and shows certificate picker GUI during runtime to choose an already imported certificate.
.EXAMPLE
Install-WAC -UseCertificate Existing -Thumbprint 2533F098AEF323C4438E6B5503CFC462DF5B598C
Installs Windows Admin Center from $temp\WAC.msi with port 443 and an already imported certificate with the thumbprint 2533F098AEF323C4438E6B5503CFC462DF5B598C.
.PARAMETER SetupPath
The full path to the Windows Admin Center setup file.
.PARAMETER Port
The port you want to use for Windows Admin Center. For desktop mode, you have to specify a port higher than 1023.
.PARAMETER UseCertificate
Has to be one of the three options:
	SelfSigned: Uses self signed certficate from setup routine
	Request: Tries to request web server certificate from your ca
	Existing: Shows certicate picker GUI during runtime to choose an already imported certificate
.PARAMETER Thumbprint
Specify thumbprint of an already imported certificate.
When using this parameter you have to use -UseCertificate Existing.
#>
[cmdletbinding()]
param (
	[parameter(mandatory = $false, position = 1)]
	[string]$SetupPath = "$Env:Temp\WAC.msi",
	[parameter(mandatory = $false, position = 2)]
	[int]$Port = 443,
	[parameter(mandatory = $false, position = 3)]
	[ValidateSet("SelfSigned", "Request", "Existing")]
	[string]$UseCertificate = "SelfSigned",
	[parameter(mandatory = $false, position = 4)]
	[string]$Thumbprint
)

Add-Type –AssemblyName System.Windows.Forms

Write-Host "Checking supported operating systems"
$OSwmi = Get-WmiObject -class Win32_OperatingSystem
if ($OSwmi.version -like "10.*")
{
	if ($OSwmi.caption -like "*Windows 10*")
	{
		$OS = "Client"
	}
	else
	{
		$OS = "Server"
	}
	Write-Host "Setting OS to $OS"
}
else
{
	[System.Windows.Forms.MessageBox]::Show("Operating system not supported! Please use Windows 10 (desktop mode) or Windows Server 2016/1709 or newer (gateway mode).", "Error", 0)
	break
}

if (Test-Path $SetupPath)
{
	if ($SetupPath -notlike "*.msi")
	{
		[System.Windows.Forms.MessageBox]::Show("Setup path has to point to Windows Admin Center MSI file.", "Error", 0)
		break
	}
	
}
else
{
	[System.Windows.Forms.MessageBox]::Show("Setup path has to point to Windows Admin Center MSI file.", "Error", 0)
	break
}

if ($OS -eq "Client")
{
	if ($Port -lt 1024)
	{
		[System.Windows.Forms.MessageBox]::Show("Please specify a port higher than 1023 with the -Port parameter for desktop mode installation.", "Error", 0)
		break
	}
	Write-Host "Starting installation of Windows Admin Center with self signed certificate in desktop mode from $SetupPath with port $Port"
	$Installation = Start-Process msiexec.exe -Wait -ArgumentList "/i `"$SetupPath`" /qn /L*v log.txt SME_PORT=$Port" -PassThru
	if ($Installation.ExitCode -eq 0 -or $Installation.ExitCode -eq 3010)
	{
		[System.Windows.Forms.MessageBox]::Show("Installation successful: Exitcode " + $Installation.ExitCode, "Success", 0)
		break
	}
	else
	{
		[System.Windows.Forms.MessageBox]::Show("Installation failed: Exitcode " + $Installation.ExitCode, "Error", 0)
		break
	}
}
elseif ($OS -eq "Server")
{
	if ($UseCertificate -eq "Request")
	{
		Write-Host "Trying to request SSL certificate from ca"
		Start-Process certutil.exe -Wait -ArgumentList "-pulse"
		$fqdn = (Resolve-DnsName -Name $env:COMPUTERNAME | Select-Object -First 1).Name
		$cert = Get-Certificate -Template WebServer -DnsName $env:COMPUTERNAME, $fqdn -CertStoreLocation cert:\LocalMachine\My -ErrorAction Ignore
		$Thumbprint = $cert.Certificate.Thumbprint
		if (-not ($Thumbprint))
		{
			[System.Windows.Forms.MessageBox]::Show("Request failed, please import SSL certificate manually and use parameter -UseCertificate Existing.", "Error", 0)
			break
		}
	}
	elseif ($UseCertificate -eq "Existing")
	{
		if (-not ($Thumbprint))
		{
			[System.Windows.Forms.MessageBox]::Show("Please select SSL certificate to be used for Windows Admin Center and press OK.`nATTENTION: Certificate with subject 'Windows Admin Center' is the self signed certificate that will expire in 60 days!", "Certificate Picker", 0)
			$Thumbprint = Get-ChildItem -path cert:\LocalMachine\My | Select-Object -Property Thumbprint, Issuer, Subject, DnsNameList | Out-GridView -PassThru | Select-Object -ExpandProperty Thumbprint
			if (-not ($Thumbprint))
			{
				[System.Windows.Forms.MessageBox]::Show("No SSL certificate selected.", "Error", 0)
				break
			}
		}
	}
	else
	{
		Write-Host "Starting installation of Windows Admin Center with self signed certificate in gateway mode from $SetupPath with port $Port"
		$Installation = Start-Process msiexec.exe -Wait -ArgumentList "/i `"$SetupPath`" /qn /L*v log.txt SME_PORT=$Port" -PassThru
		if ($Installation.ExitCode -eq 0 -or $Installation.ExitCode -eq 3010)
		{
			[System.Windows.Forms.MessageBox]::Show("Installation successful: Exitcode " + $Installation.ExitCode, "Success", 0)
			break
		}
		else
		{
			[System.Windows.Forms.MessageBox]::Show("Installation failed: Exitcode " + $Installation.ExitCode, "Error", 0)
			break
		}
	}
	
	Write-Host "Starting installation of Windows Admin Center with SSL certificate $Thumbprint in gateway mode from $SetupPath with port $Port"
	$Installation = Start-Process msiexec.exe -Wait -ArgumentList "/i `"$SetupPath`" /qn /L*v log.txt REGISTRY_REDIRECT_PORT_80=1 SME_PORT=$Port SME_THUMBPRINT=$Thumbprint SSL_CERTIFICATE_OPTION=installed" -PassThru
	if ($Installation.ExitCode -eq 0 -or $Installation.ExitCode -eq 3010)
	{
		[System.Windows.Forms.MessageBox]::Show("Installation successful: Exitcode " + $Installation.ExitCode, "Success", 0)
		break
	}
	else
	{
		[System.Windows.Forms.MessageBox]::Show("Installation failed: Exitcode " + $Installation.ExitCode, "Error", 0)
		break
	}
}