﻿<#
.SYNOPSIS
Backs up and restores Windows Admin Center configuration
.DESCRIPTION
Backs up and restores Windows Admin Center configuration to and from %temp%\WAC.zip by default. You can specify the backup path and the filename with parameters.
.EXAMPLE
Backup-WAC
Backs up Windows Admin Center configuration to %temp%\WAC.zip.
.EXAMPLE
Backup-WAC -BackupPath "C:\Temp" -Filename "WACBackup.zip"
Backs up Windows Admin Center configuration to C:\Temp\WACBackup.zip.
.EXAMPLE
Backup-WAC -Mode Restore
Restores Windows Admin Center configuration from %temp%\WAC.zip.
.EXAMPLE
Backup-WAC -Mode Restore -BackupPath "C:\Temp" -Filename "WACBackup.zip"
Restores Windows Admin Center configuration from C:\Temp\WACBackup.zip.
.PARAMETER Mode
Operation mode must be one of the two options:
	Backup: Backs up Windows Admin Center configuration
	Restore: Restores Windows Admin Center configuration
.PARAMETER BackupPath
The path where you want to save the backup
.PARAMETER Filename
The filename of the backup file
#>
[cmdletbinding()]
param (
	[parameter(mandatory = $false, position = 1)]
	[ValidateSet("Backup", "Restore")]
	[string]$Mode = "Backup",
	[parameter(mandatory = $false, position = 2)]
	[string]$BackupPath = "$env:TEMP",
	[parameter(mandatory = $false, position = 3)]
	[string]$Filename = "WAC.zip"
)

$WACConfigPath = "C:\Windows\ServiceProfiles\NetworkService\AppData\Roaming\Microsoft\ServerManagementExperience"

if ($Mode -eq "Backup")
{
	if (-Not (Test-Path "$WACConfigPath"))
	{
		[System.Windows.Forms.MessageBox]::Show("Windows Admin Center configuration not found.", "Error", 0)
		break
	}
	if (Test-Path "$BackupPath\$Filename")
	{
		$MsgBox = [System.Windows.Forms.MessageBox]::Show("File already exists, overwrite?", "Warning", 1)
		if ($MsgBox -eq [System.Windows.Forms.DialogResult]::Cancel)
		{
			return
		}
	}
}

Write-Host "Stopping Windows Admin Center service"
Stop-Service ServerManagementGateway -Force
Start-Sleep -Seconds 5

if ($Mode -eq "Backup")
{
	Write-Host "Backing up Windows Admin Center Configuration to $BackupPath\$Filename"
	Compress-Archive -DestinationPath "$BackupPath\$Filename" -Path "$WACConfigPath\*" -CompressionLevel Optimal -Force
	Write-Host "Backup completed"
}
elseif ($Mode -eq "Restore")
{
	Write-Host "Restoring Windows Admin Center Configuration from $BackupPath\$Filename"
	Remove-Item "$WACConfigPath" -Force -Recurse
	Expand-Archive -Path "$BackupPath\$Filename" -DestinationPath "$WACConfigPath"
	Write-Host "Restore completed"
}

Write-Host "Starting Windows Admin Center service"
Start-Service ServerManagementGateway